<?php
session_start();
require_once 'db.php';

// Define the current page for sidebar highlighting
$currentPage = 'polls_view.php';

// 🔐 Auth check
if (!isset($_SESSION['currentUser'])) {
    header("Location: login.php");
    exit;
}

$currentUser = $_SESSION['currentUser'];
$userId = $currentUser['id'] ?? null;

function sane($s)
{
    return htmlspecialchars(trim($s ?? ''), ENT_QUOTES, 'UTF-8');
}

// 🧭 Fetch polls and their options
$stmt = $pdo->prepare("
    SELECT p.*, u.first_name, u.last_name
    FROM polls p
    LEFT JOIN users u ON p.created_by = u.id
    ORDER BY p.created_at DESC
");
$stmt->execute();
$polls = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>AgoraBoard - Polls</title>
    <link rel="stylesheet" href="assets/dashboard.css?v=<?= time(); ?>">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        /* Custom styles for the confirmation box */
        #logoutConfirmModal {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            z-index: 1050;
            background-color: white;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            max-width: 350px;
            width: 90%;
            display: none; /* Hidden by default */
        }
        #modalBackdrop {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.4);
            z-index: 1040;
            display: none; /* Hidden by default */
        }
    </style>
</head>

<body>
    <div class="dashboard-layout d-flex">

        <!-- ✅ Sidebar Included -->
        <?php require_once 'user_sidebar.php'; ?>

        <!-- ✅ Main Content -->
        <div class="main-content flex-grow-1 p-4">
            <div class="main-header mb-4 d-flex justify-content-between align-items-center">
                <h3 style="font-weight:700;">🗳️ Community Polls</h3>
            </div>

            <!-- ✅ Create Poll Card -->
            <div class="post-card mb-4 p-4 shadow-sm">
                <form id="createPollForm" method="POST" action="poll_create.php">
                    <div class="mb-3">
                        <label for="pollQuestion" class="form-label fw-semibold">Poll Question</label>
                        <input type="text" id="pollQuestion" name="question" class="form-control input-underline" placeholder="e.g., What project feature should we prioritize next?" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-semibold">Options</label>
                        <div id="pollOptionsContainer">
                            <div class="d-flex gap-2 mb-2">
                                <input type="text" name="options[]" class="form-control" placeholder="Option 1" required>
                            </div>
                            <div class="d-flex gap-2 mb-2">
                                <input type="text" name="options[]" class="form-control" placeholder="Option 2" required>
                            </div>
                        </div>
                        <button type="button" id="addOptionBtn" class="btn btn-sm" style="background-color: var(--sage); color:#fff;">
                            <i class="bi bi-plus-circle"></i> Add Option
                        </button>
                    </div>

                    <div class="text-end mt-3">
                        <button type="submit" class="btn" style="background-color:var(--sage-light); color:white; border-radius:8px; padding:6px 20px;">
                            <i class="bi bi-send me-1"></i> Create Poll
                        </button>
                    </div>
                </form>
            </div>

            <!-- ✅ Polls Feed -->
            <div class="main-feed">
                <?php if (empty($polls)): ?>
                    <div class="text-center p-5" style="color: var(--muted-text); background:#fff; border:1px solid var(--border-color); border-radius:12px;">
                        <i class="bi bi-clipboard-check fs-3 d-block mb-2" style="color:var(--sage-light);"></i>
                        <strong>No polls yet.</strong>
                        <p class="mt-2 mb-0">Be the first to create a poll!</p>
                    </div>
                <?php else: ?>
                    <?php foreach ($polls as $poll): ?>
                        <?php
                        $pollId = $poll['id'];
                        $pollUser = trim(($poll['first_name'] ?? '') . ' ' . ($poll['last_name'] ?? '')) ?: 'Anonymous';
                        $pollTime = date('M d, Y • h:i A', strtotime($poll['created_at']));

                        // Fetch options + votes
                        $optStmt = $pdo->prepare("
                        SELECT o.id, o.option_text,
                            (SELECT COUNT(*) FROM poll_votes v WHERE v.option_id = o.id) AS votes
                        FROM poll_options o
                        WHERE o.poll_id = ?
                        ");
                        $optStmt->execute([$pollId]);
                        $options = $optStmt->fetchAll(PDO::FETCH_ASSOC);

                        $totalVotes = array_sum(array_column($options, 'votes'));
                        ?>
                        <div class="post-card mb-3 p-4 shadow-sm">
                            <div class="d-flex justify-content-between align-items-start mb-2">
                                <div>
                                    <strong><?= sane($pollUser); ?></strong>
                                    <small class="d-block text-muted"><?= sane($pollTime); ?></small>
                                </div>
                                <span class="badge bg-success-subtle text-success border border-success-subtle">Poll</span>
                            </div>

                            <h5 class="post-title mb-3"><?= sane($poll['question']); ?></h5>

                            <form class="pollVoteForm" method="POST" action="poll_vote.php">
                                <input type="hidden" name="poll_id" value="<?= $pollId; ?>">
                                <?php foreach ($options as $opt): ?>
                                    <?php
                                    $percentage = $totalVotes > 0 ? round(($opt['votes'] / $totalVotes) * 100, 1) : 0;
                                    ?>
                                    <div class="mb-2">
                                        <label class="w-100">
                                            <input type="radio" name="option_id" value="<?= $opt['id']; ?>" required>
                                            <?= sane($opt['option_text']); ?>
                                        </label>
                                        <div class="progress mt-1" style="height:6px; border-radius:4px;">
                                            <div class="progress-bar" role="progressbar"
                                                style="width: <?= $percentage; ?>%; background-color:var(--sage);"
                                                aria-valuenow="<?= $percentage; ?>" aria-valuemin="0" aria-valuemax="100">
                                            </div>
                                        </div>
                                        <small class="text-muted"><?= $opt['votes']; ?> votes (<?= $percentage; ?>%)</small>
                                    </div>
                                <?php endforeach; ?>

                                <div class="text-end mt-3">
                                    <button type="submit" class="btn btn-sm" style="background-color:var(--sage); color:white; border-radius:8px;">
                                        <i class="bi bi-check2-circle me-1"></i> Vote
                                    </button>
                                </div>
                            </form>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Non-blocking Logout Confirmation Modal/Div -->
    <div id="modalBackdrop"></div>
    <div id="logoutConfirmModal">
        <h5 class="mb-3"><i class="bi bi-question-circle me-2"></i> Confirm Logout</h5>
        <p>Are you sure you want to log out of AgoraBoard?</p>
        <div class="d-flex justify-content-end gap-2 mt-4">
            <button type="button" class="btn btn-secondary btn-sm" onclick="hideLogoutConfirm()">Cancel</button>
            <button type="button" class="btn btn-danger btn-sm" onclick="submitLogout()">Logout</button>
        </div>
    </div>

    <script>
        // 🟢 Add poll options dynamically
        document.getElementById('addOptionBtn').addEventListener('click', function() {
            const container = document.getElementById('pollOptionsContainer');
            const optionCount = container.children.length + 1;
            const div = document.createElement('div');
            div.classList.add('d-flex', 'gap-2', 'mb-2');
            div.innerHTML = `
            <input type="text" name="options[]" class="form-control" placeholder="Option ${optionCount}" required>
            <button type="button" class="btn btn-outline-danger btn-sm removeOptionBtn" aria-label="Remove option"><i class="bi bi-x"></i></button>
            `;
            container.appendChild(div);
            // Attach removal logic to the new button
            div.querySelector('.removeOptionBtn').addEventListener('click', () => div.remove());
        });

        // 🔐 Non-blocking Logout Confirmation (Replaces forbidden confirm())
        const modal = document.getElementById('logoutConfirmModal');
        const backdrop = document.getElementById('modalBackdrop');

        window.confirmLogout = function() {
            modal.style.display = 'block';
            backdrop.style.display = 'block';
        };

        window.hideLogoutConfirm = function() {
            modal.style.display = 'none';
            backdrop.style.display = 'none';
        };

        window.submitLogout = function() {
            document.getElementById('logoutForm').submit();
        };

        // Close modal when clicking outside (on backdrop)
        backdrop.addEventListener('click', hideLogoutConfirm);
    </script>

</body>

</html>