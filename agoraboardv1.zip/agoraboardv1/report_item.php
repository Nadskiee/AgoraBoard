<?php
session_start();
require_once 'db.php';

// 1. 🔐 AUTHENTICATION CHECK
if (!isset($_SESSION['currentUser'])) {
    header("Location: login.php");
    exit;
}

// Initialize feedback message
$message = '';
$message_type = 'danger';

// 2. 💻 FORM SUBMISSION CHECK
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // 3. 📄 GET FORM DATA
    $status = $_POST['status'];
    $category = $_POST['category'];
    $item_name = trim($_POST['item_name']);
    $description = trim($_POST['description']);
    $location = trim($_POST['location']);
    $date = $_POST['date_lost_found'];
    $posted_by = $_POST['posted_by'];

    $image_path = null;
    $uploadOk = 1;

    // 4. 🖼️ IMAGE UPLOAD HANDLING
    if (isset($_FILES['itemImage']) && $_FILES['itemImage']['error'] == 0) {

        // Absolute path for move_uploaded_file()
        $target_dir = __DIR__ . "/uploads/";

        // URL path saved in DB
        $public_dir = "uploads/";

        // Create folder if missing
        if (!is_dir($target_dir)) {
            mkdir($target_dir, 0777, true);
        }

        // Safe unique filename
        $image_ext = strtolower(pathinfo($_FILES["itemImage"]["name"], PATHINFO_EXTENSION));
        $safe_filename = uniqid('item_', true) . '.' . $image_ext;

        // Full filesystem path
        $target_file = $target_dir . $safe_filename;

        // URL for DB
        $image_path = $public_dir . $safe_filename;

        // IMAGE VALIDATION
        if (getimagesize($_FILES["itemImage"]["tmp_name"]) === false) {
            $message = "File is not a valid image.";
            $uploadOk = 0;
        } elseif ($_FILES["itemImage"]["size"] > 5000000) {
            $message = "Sorry, file is too large. Max 5MB.";
            $uploadOk = 0;
        }

        $allowed_types = ['jpg', 'jpeg', 'png'];
        if (!in_array($image_ext, $allowed_types)) {
            $message = "Only JPG, JPEG, and PNG are allowed.";
            $uploadOk = 0;
        }

        // Move file
        if ($uploadOk == 1) {
            if (!move_uploaded_file($_FILES["itemImage"]["tmp_name"], $target_file)) {
                $message = "Error uploading file. Check folder permissions.";
                $uploadOk = 0;
            }
        }

    } else {
        $message = "Please upload an image.";
        $uploadOk = 0;
    }

    // 5. 💾 DATABASE INSERTION
    if ($uploadOk == 1 && $image_path !== null) {
        try {
            $sql = "INSERT INTO lost_and_found 
                        (status, category, item_name, description, last_seen_location, date_lost_found, posted_by, image_path)
                    VALUES 
                        (:status, :category, :item_name, :description, :location, :date, :posted_by, :image_path)";

            $stmt = $pdo->prepare($sql);
            $stmt->bindParam(':status', $status);
            $stmt->bindParam(':category', $category);
            $stmt->bindParam(':item_name', $item_name);
            $stmt->bindParam(':description', $description);
            $stmt->bindParam(':location', $location);
            $stmt->bindParam(':date', $date);
            $stmt->bindParam(':posted_by', $posted_by);
            $stmt->bindParam(':image_path', $image_path);

            $stmt->execute();

            // Redirect on success
            header("Location: lost_and_found.php");
            exit;

        } catch (PDOException $e) {
            $message = "Database error: " . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Error</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <div class="alert alert-<?php echo $message_type; ?>" role="alert">
            <h4 class="alert-heading">An Error Occurred</h4>
            <p><?php echo htmlspecialchars($message); ?></p>
            <hr>
            <a href="lost_and_found.php" class="btn btn-primary">Go Back</a>
        </div>
    </div>
</body>
</html>
