<?php
session_start();
require_once 'db.php';

// 🔐 Auth check
if (!isset($_SESSION['currentUser'])) {
    header("Location: login.php");
    exit;
}
$currentUser = $_SESSION['currentUser'];
$userId = $currentUser['id'] ?? null;

// 🧼 Helper
function sane($s)
{
    return htmlspecialchars(trim($s), ENT_QUOTES, 'UTF-8');
}

// 📝 Handle post creation
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['new_post_content'])) {
    $content = sane($_POST['new_post_content']);
    $categoryId = !empty($_POST['new_post_category']) ? (int)$_POST['new_post_category'] : null;
    $title = sane($_POST['new_post_title'] ?? '');
    $stmt = $pdo->prepare("INSERT INTO community_posts (title, content, category_id, created_by, created_at) VALUES (?, ?, ?, ?, NOW()) ");
    $stmt->execute([$title, $content, $categoryId, $userId]);
    header("Location: dashboard.php");
    exit;
}

// ✏️ Edit post (AJAX)
if (
    $_SERVER['REQUEST_METHOD'] === 'POST' &&
    isset($_POST['edit_post_index'], $_POST['edit_post_content']) &&
    strtolower($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') === 'xmlhttprequest'
) {
    header('Content-Type: application/json');
    $postId = (int)$_POST['edit_post_index'];
    $newContent = sane($_POST['edit_post_content']);
    $newTitle = sane($_POST['edit_post_title'] ?? '');
    $categoryId = !empty($_POST['edit_post_category']) ? (int)$_POST['edit_post_category'] : null;

    $stmt = $pdo->prepare("
        UPDATE community_posts
        SET title = ?, content = ?, category_id = ?
        WHERE id = ? AND created_by = ?
    ");
    $stmt->execute([$newTitle, $newContent, $categoryId, $postId, $userId]);

    echo json_encode([
        'success' => $stmt->rowCount() > 0,
        'message' => $stmt->rowCount() > 0 ? 'Post updated' : 'Unauthorized or no changes'
    ]);
    exit;
}

// 🗑️ Soft delete post
if (isset($_POST['delete_post_id'])) {
    $postId = (int)$_POST['delete_post_id'];
    $now = date('Y-m-d H:i:s');
    $stmt = $pdo->prepare("UPDATE community_posts SET deleted_at=? WHERE id=? AND created_by=?");
    $stmt->execute([$now, $postId, $userId]);
}


// ❤️ Like/unlike post (AJAX)
if (
    $_SERVER['REQUEST_METHOD'] === 'POST' &&
    isset($_POST['like_post_id']) &&
    strtolower($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') === 'xmlhttprequest'
) {

    $postId = (int)$_POST['like_post_id'];

    $check = $pdo->prepare("SELECT id FROM likes WHERE user_id=? AND post_type='community' AND post_id=? AND deleted_at IS NULL");
    $check->execute([$userId, $postId]);

    $now = date('Y-m-d H:i:s');

    if ($check->rowCount() > 0) {
        $pdo->prepare("UPDATE likes SET deleted_at=? WHERE user_id=? AND post_type='community' AND post_id=?")->execute([$now, $userId, $postId]);
        $liked = false;
    } else {
        $pdo->prepare("INSERT INTO likes (user_id, post_type, post_id) VALUES (?, 'community', ?)")->execute([$userId, $postId]);
        $liked = true;
    }

    $count = $pdo->prepare("SELECT COUNT(*) FROM likes WHERE post_type='community' AND post_id=? AND deleted_at IS NULL");
    $count->execute([$postId]);
    $totalLikes = $count->fetchColumn();

    echo json_encode([
        'success' => true,
        'liked' => $liked,
        'total_likes' => $totalLikes
    ]);
    exit;
}

// 🗑️ Soft delete comment (AJAX)
if (
    $_SERVER['REQUEST_METHOD'] === 'POST' &&
    isset($_POST['delete_comment_id']) &&
    strtolower($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') === 'xmlhttprequest'
) {

    $commentId = (int)$_POST['delete_comment_id'];
    $now = date('Y-m-d H:i:s');
    $pdo->prepare("UPDATE comments SET deleted_at=? WHERE id=? AND user_id=?")->execute([$now, $commentId, $userId]);
    echo json_encode(['success' => true]);
    exit;
}

// ✏️ Edit comment (AJAX)
if (
    $_SERVER['REQUEST_METHOD'] === 'POST' &&
    isset($_POST['comment_id'], $_POST['comment_text']) &&
    strtolower($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') === 'xmlhttprequest'
) {

    $commentId = (int)$_POST['comment_id'];
    $text = sane($_POST['comment_text']);

    $stmt = $pdo->prepare("UPDATE comments SET content=? WHERE id=? AND user_id=? AND deleted_at IS NULL");
    $stmt->execute([$text, $commentId, $userId]);

    echo json_encode(['success' => true]);
    exit;
}

// 📅 Fetch unpinned posts
$stmtUnpinned = $pdo->query("
    SELECT p.*, 
           u.first_name, u.last_name, u.role,
           c.name AS category_name,
           (SELECT COUNT(*) FROM likes WHERE post_type='community' AND post_id=p.id AND deleted_at IS NULL) AS total_likes,
           (SELECT COUNT(*) FROM comments WHERE post_type='community' AND post_id=p.id AND deleted_at IS NULL) AS total_comments,
           (SELECT COUNT(*) FROM bookmarks WHERE post_type='community' AND post_id=p.id AND deleted_at IS NULL) AS total_bookmarks
    FROM community_posts p
    LEFT JOIN users u ON p.created_by = u.id
    LEFT JOIN categories c ON p.category_id = c.id
    WHERE p.is_pinned = 0 AND p.deleted_at IS NULL
    ORDER BY p.created_at DESC
");

$posts = $stmtUnpinned->fetchAll(PDO::FETCH_ASSOC);

// 📅 Fetch pinned posts
$stmtPinned = $pdo->query("
    SELECT p.*, 
           u.first_name, u.last_name, u.role,
           c.name AS category_name,
           (SELECT COUNT(*) FROM likes WHERE post_type='community' AND post_id=p.id AND deleted_at IS NULL) AS total_likes,
           (SELECT COUNT(*) FROM comments WHERE post_type='community' AND post_id=p.id AND deleted_at IS NULL) AS total_comments,
           (SELECT COUNT(*) FROM bookmarks WHERE post_type='community' AND post_id=p.id AND deleted_at IS NULL) AS total_bookmarks
    FROM community_posts p
    LEFT JOIN users u ON p.created_by = u.id
    LEFT JOIN categories c ON p.category_id = c.id
    WHERE p.is_pinned = 1 AND p.deleted_at IS NULL
    ORDER BY p.created_at DESC
");

$pinnedPosts = $stmtPinned->fetchAll(PDO::FETCH_ASSOC);

// 💬 Fetch comments per post
function getComments($pdo, $postId)
{
    $q = $pdo->prepare("
        SELECT c.*, u.first_name, u.last_name 
        FROM comments c 
        LEFT JOIN users u ON c.user_id = u.id 
        WHERE c.post_type='community' AND c.post_id=? AND c.deleted_at IS NULL
        ORDER BY c.created_at ASC
    ");
    $q->execute([$postId]);
    return $q->fetchAll(PDO::FETCH_ASSOC);
}

// 📅 Upcoming events
$today = date('Y-m-d');
$stmt = $pdo->prepare("
    SELECT 
        e.id,
        e.title,
        e.event_date,
        e.location,
        COUNT(a.user_id) AS attendees
    FROM events e
    LEFT JOIN event_attendees a ON e.id = a.event_id AND a.deleted_at IS NULL
    WHERE e.event_date >= ? AND e.deleted_at IS NULL
    GROUP BY e.id
    ORDER BY e.event_date ASC
    LIMIT 5
");
$stmt->execute([$today]);
$events = $stmt->fetchAll(PDO::FETCH_ASSOC);

// 📝 FIXED: Handle report submission (AJAX)
if (
    $_SERVER['REQUEST_METHOD'] === 'POST' &&
    isset($_POST['reason'], $_POST['post_id']) && // Check for a key field
    strtolower($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') === 'xmlhttprequest'
) {
    header('Content-Type: application/json');

    $userId = $_SESSION['currentUser']['id'] ?? null;
    $postId = $_POST['post_id'] ?? null;
    $postType = $_POST['post_type'] ?? 'community'; // Add a default
    $reason = $_POST['reason'] ?? null;
    $otherReason = trim($_POST['other_reason'] ?? '');

    if ($reason === 'Other' && empty($otherReason)) {
        echo json_encode(['success' => false, 'message' => 'Please specify the reason.']);
        exit;
    }
    
    if (empty($reason)) {
        echo json_encode(['success' => false, 'message' => 'A reason is required.']);
        exit;
    }

    $finalReason = $reason === 'Other' ? $otherReason : $reason;

    try {
        $stmt = $pdo->prepare("INSERT INTO reports (reporter_id, post_type, post_id, reason) VALUES (?, ?, ?, ?)");
        $stmt->execute([$userId, $postType, $postId, $finalReason]);

        echo json_encode(['success' => true, 'message' => 'Report submitted successfully.']);
    } catch (PDOException $e) {
       
        echo json_encode(['success' => false, 'message' => 'Error submitting report.']);
    }
    exit; // Stop the script
}

?>

<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>AgoraBoard - Home</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/dashboard.css?v=<?php echo time(); ?>">
</head>

<body>
    <?php include 'user_sidebar.php'; ?>
    <div class="modal fade" id="editPostModal" tabindex="-1" aria-labelledby="editPostModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form id="editPostForm" method="POST" action="">
                    <div class="modal-header">
                        <h5 class="modal-title" id="editPostModalLabel">Edit Post</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <input type="text" id="editPostTitle" name="edit_post_title" class="input-underline mb-3 w-100" placeholder="Post title (optional)">
                        <input type="hidden" name="edit_post_index" id="editPostIndex">
                        <textarea name="edit_post_content" id="editPostContent" class="form-control" rows="5" required></textarea>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary bg-success border-success">Save changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade" id="editCommentModal" tabindex="-1" aria-labelledby="editCommentModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-md">
            <div class="modal-content">
                <form id="editCommentForm" method="POST" action="">
                    <div class="modal-header">
                        <h5 class="modal-title" id="editCommentModalLabel">Edit Comment</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" name="edit_comment_post" id="editCommentPostIndex">
                        <input type="hidden" name="edit_comment_index" id="editCommentIndex">
                        <textarea name="edit_comment_text" id="editCommentText" class="form-control" rows="3" required></textarea>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary btn-sm bg-success border-success">Save changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- Report Post Modal -->
    <div class="modal fade" id="reportModal" tabindex="-1" aria-labelledby="reportModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-md">
            <div class="modal-content">
                <form id="reportForm" method="POST">
                    <input type="hidden" name="post_id" id="reportPostId">
                    <input type="hidden" name="category_id" id="reportCategoryId">

                    <div class="modal-header">
                        <h5 class="modal-title" id="reportModalLabel">Report Post</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>

                    <div class="modal-body">
                        <label for="reason" class="form-label">Reason for reporting:</label>
                        <select name="reason" id="reason" class="form-select mb-3" required>
                            <option value="">-- Select Reason --</option>
                            <option value="Spam">Spam</option>
                            <option value="Harassment or Bullying">Harassment or Bullying</option>
                            <option value="Hate Speech">Hate Speech</option>
                            <option value="Nudity or Sexual Content">Nudity or Sexual Content</option>
                            <option value="False Information">False Information</option>
                            <option value="Other">Other</option>
                        </select>

                        <div id="otherReasonDiv" style="display: none;">
                            <label for="other_reason" class="form-label">Please specify:</label>
                            <textarea name="other_reason" id="other_reason" class="form-control" rows="3" placeholder="Describe your reason"></textarea>
                        </div>
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-danger btn-sm">Report</button>
                    </div>
                </form>
            </div>
        </div>
    </div>


    <div class="main-content">
        <header class="main-header mb-4 d-flex justify-content-between align-items-center flex-wrap gap-3">

            <!-- 🔍 Search Bar -->
            <div class="search-bar flex-grow-1">
                <div class="input-group">
                    <span class="input-group-text bg-white border-end-0"><i class="bi bi-search"></i></span>
                    <input id="searchInput" type="text" class="form-control border-start-0" placeholder="Search announcements...">
                </div>
            </div>
            <div>
                <select id="sortSelect" class="form-select form-select">
                    <option value="newest">Newest</option>
                    <option value="oldest">Oldest</option>
                    <option value="mostLiked">Most Liked</option>
                    <option value="mostCommented">Most Commented</option>
                </select>
            </div>

            <!-- 🔔 Notifications & Profile -->
            <div class="d-flex align-items-center gap-3">

                <!-- Notification Bell -->
                <div class="dropdown position-relative">
                    <button class="btn border-0 p-0 position-relative" type="button" data-bs-toggle="dropdown" aria-expanded="false" data-bs-auto-close="false" title="Notifications">
                        <i class="bi bi-bell-fill fs-5 text-dark"></i>
                        <span id="notificationBadge" class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger d-none">
                            <span id="unreadCount">0</span>
                            <span class="visually-hidden">unread notifications</span>
                        </span>
                    </button>

                    <ul class="dropdown-menu dropdown-menu-end notifications-dropdown shadow-sm p-0 mt-2" style="min-width: 300px;">
                        <li class="p-3 border-bottom fw-bold">Notifications</li>
                        <!-- ✅ Direct injection target -->
                        <ul id="notificationList" class="list-unstyled m-0"></ul>
                        <li>
                            <a class="dropdown-item text-center small p-2" href="notifications.php">View all notifications</a>

                </div>

                <!-- Profile Dropdown -->
                <div class="dropdown">
                    <a href="profile.php" class="header-profile-btn d-flex align-items-center rounded-pill py-1 pe-2 text-decoration-none" title="User Profile">
                        <div class="avatar me-2 bg-secondary text-white fw-bold">
                            <?= strtoupper(substr($currentUser['initial'] ?? $currentUser['name'] ?? '?', 0, 1)); ?>
                        </div>
                        <div class="d-none d-md-block text-start me-2">
                            <span class="d-block lh-1 fw-bold text-dark" style="font-size: 0.9rem;">
                                <?= sane($currentUser['name'] ?? 'Anonymous'); ?>
                            </span>
                            <small class="badge bg-success rounded-pill px-2 py-0" style="font-size: 0.65rem;">
                                <?= strtoupper(sane($currentUser['role'] ?? 'Member')); ?>
                            </small>
                        </div>
                        <i class="bi bi-chevron-right text-muted small"></i>
                    </a>
                </div>
            </div>
        </header>

        <div class="d-flex gap-4">
            <div class="main-feed">
                <div class="d-flex gap-2 mb-3 filter-button-group">
                    <button class="btn btn-sm active" data-tag="">ALL</button>
                    <?php
                    // ✅ Fetch categories only once at the top
                    $categories = $pdo->query("SELECT id, name FROM categories WHERE deleted_at IS NULL ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);
                    $defaultCategoryId = $categories[0]['id'] ?? null;
                    foreach ($categories as $cat):
                        $catName = htmlspecialchars($cat['name'], ENT_QUOTES);
                        $safeDataTag = htmlspecialchars($cat['name'], ENT_QUOTES);
                    ?>
                        <button class="btn btn-sm" data-tag="<?= $safeDataTag; ?>">
                            <?= strtoupper($catName); ?>
                        </button>
                    <?php endforeach; ?>
                </div>


                <div class="composer mb-4">
                    <form method="POST">
                        <div class="d-flex gap-3">
                            <!-- 👤 Avatar -->
                            <div class="avatar"><?= $currentUser['initial'] ?? '?'; ?></div>

                            <!-- 📝 Post Fields -->
                            <div class="w-100">
                                <!-- Title Input -->
                                <input type="text"
                                    name="new_post_title"
                                    class="input-underline mb-2"
                                    placeholder="Post title (optional)">


                                <!-- Content Textarea -->
                                <textarea name="new_post_content"
                                    class="form-control"
                                    placeholder="What's happening in your community?"
                                    rows="3"
                                    required></textarea>
                            </div>
                        </div>

                        <hr class="my-3">
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="d-flex flex-column flex-grow-1 me-3">
                                <!-- 🏷️ Tag Selection -->
                                <div class="d-flex gap-2 flex-wrap">
                                    <?php foreach ($categories as $cat):
                                        $safeId = 'tag_' . strtolower(str_replace([' ', '&'], ['_', 'and'], $cat['name']));
                                    ?>
                                        <input type="radio"
                                            class="btn-check"
                                            name="new_post_category"
                                            id="<?= $safeId; ?>"
                                            value="<?= $cat['id']; ?>"
                                            <?= ($cat['id'] == $defaultCategoryId) ? 'checked' : ''; ?>>

                                        <label class="btn btn-outline-secondary btn-sm tag-btn"
                                            for="<?= $safeId; ?>">
                                            <?= htmlspecialchars($cat['name'], ENT_QUOTES); ?>
                                        </label>
                                    <?php endforeach; ?>

                                </div>
                            </div>

                            <!-- 🚀 Submit Button -->
                            <button type="submit" class="btn btn-post align-self-start">Post</button>
                        </div>

                    </form>
                </div>

                <!-- Posts -->
                <div id="postsContainer">
                    <?php foreach ($posts as $i => $post): ?>
                        <?php
                        $postId = $post['id'];
                        $postType = 'community';
                        $first = trim($post['first_name'] ?? '');
                        $last = trim($post['last_name'] ?? '');
                        $postUser = ($first || $last) ? "$first $last" : 'Anonymous';

                        $postRole = $post['role'] ?? '';
                        $postTime = date('M d, Y H:i', strtotime($post['created_at']));
                        $postTag = $post['category_name'] ?? 'General';
                        $postTitle = $post['title'] ?? '';
                        $postContent = $post['content'] ?? '';
                        $postLikes = $post['total_likes'] ?? 0;
                        $postComments = $post['total_comments'] ?? 0;

                        $isCurrentUserPost = $post['created_by'] == $userId;

                        // Like status
                        $isLiked = $pdo->prepare("SELECT 1 FROM likes WHERE post_type='community' AND post_id=? AND user_id=?");
                        $isLiked->execute([$postId, $userId]);
                        $liked = $isLiked->rowCount() > 0;

                        // Bookmark status
                        $isBookmarked = $pdo->prepare("SELECT 1 FROM bookmarks WHERE post_type='community' AND post_id=? AND user_id=?");
                        $isBookmarked->execute([$postId, $userId]);
                        $bookmarked = $isBookmarked->rowCount() > 0;

                        // Fetch comments for this post
                        $commentsForPost = getComments($pdo, $postId);

                        // Tag class for filtering
                        $tagClassMap = [
                            'Lost and Found' => 'tag-lost-and-found',
                            'Event' => 'tag-event',
                            'Alert' => 'tag-alert',
                            'Volunteer' => 'tag-volunteer',
                            'Job' => 'tag-job'
                        ];
                        $tagClass = $tagClassMap[$postTag] ?? 'tag-general';


                        ?>
                        <div id="post-<?= $postId; ?>" class="post-card mb-3" data-post-tag="<?= $postTag; ?>" data-post-likes="<?= (int)$postLikes; ?>" data-post-comments=" <?= $postComments; ?>" data-post-time="<?= $postTime; ?>">
                            <div class="d-flex gap-3">
                                <div class="avatar"><?= strtoupper(substr($postUser, 0, 1)); ?></div>
                                <div class="w-100">
                                    <div class="d-flex justify-content-between align-items-start">
                                        <div>
                                            <strong><?= sane($postUser); ?></strong>
                                            <?php if ($postRole === 'Admin'): ?>
                                                <small class="text-muted"> • <?= sane($postRole); ?></small>
                                            <?php endif; ?>
                                            <small class="text-muted d-block"><?= sane($postTime); ?></small>
                                            <?php if (!empty($postTitle)): ?>
                                                <h5 class="post-title"><?= htmlspecialchars($postTitle); ?></h5>
                                            <?php else: ?>
                                                <h5 class="text-muted post-title">Untitled Post</h5>
                                            <?php endif; ?>
                                        </div>
                                        <div class="d-flex align-items-center gap-2">
                                            <span class="badge <?= $tagClass; ?>"><?= htmlspecialchars($postTag, ENT_NOQUOTES); ?></span>
                                            <!-- 🔖 Bookmark Button -->
                                            <button class="btn-bookmark btn-as-link" data-post-id="<?= $postId; ?>" title="Bookmark">
                                                <i class="bi <?= $bookmarked ? 'bi-bookmark-fill text-warning' : 'bi-bookmark'; ?>"></i>
                                            </button>

                                            <!-- ⋮ Ellipsis Dropdown -->
                                            <div class="dropdown">
                                                <button class="btn btn-sm btn-link text-muted p-0 btn-as-link" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                                    <i class="bi bi-three-dots-vertical"></i>
                                                </button>
                                                <ul class="dropdown-menu dropdown-menu-end">
                                                    <?php if ($isCurrentUserPost): ?>
                                                        <li>
                                                            <a href="#"
                                                                class="dropdown-item edit-post-btn"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#editPostModal"
                                                                data-index="<?= $postId; ?>"
                                                                data-title="<?= htmlspecialchars($postTitle, ENT_QUOTES); ?>"
                                                                data-content="<?= htmlspecialchars($postContent, ENT_QUOTES); ?>">
                                                                <i class="bi bi-pencil me-2"></i>Edit
                                                            </a>
                                                        </li>
                                                        <li>
                                                            <form method="POST" class="m-0" onsubmit="return confirm('Delete this post?');">
                                                                <input type="hidden" name="delete_post_id" value="<?= $postId; ?>">
                                                                <button type="submit" class="dropdown-item text-danger"><i class="bi bi-trash me-2"></i>Delete</button>
                                                            </form>
                                                        </li>

                                                    <?php endif; ?>
                                                    <?php if (!$isCurrentUserPost): ?>
                                                        <li>
                                                            <a href="#"
                                                                class="dropdown-item text-danger report-post-btn"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#reportModal"
                                                                data-post-id="<?= $post['id']; ?>"
                                                                data-category-id="<?= $post['category_id']; ?>">
                                                                <i class="bi bi-flag me-2"></i>Report
                                                            </a>

                                                        </li>
                                                    <?php endif; ?>
                                                </ul>
                                            </div>

                                        </div>
                                    </div>

                                    <p class="mt-2 mb-2 post-content post-content-text"><?= nl2br(sane($postContent)); ?></p>

                                    <div class="d-flex justify-content-between align-items-center mt-3 interaction-stats">
                                        <div class="d-flex align-items-center gap-3">
                                            <!-- ❤️ Like Button -->
                                            <button class="btn-like" data-post-id="<?= $postId; ?>">
                                                <i class="bi <?= $liked ? 'bi-heart-fill text-danger' : 'bi-heart'; ?>"></i>
                                                <span class="like-count"><?= $postLikes; ?></span>
                                            </button>



                                            <!-- 💬 Comment Count + Toggle -->
                                            <a class="view-comments-toggle" data-bs-toggle="collapse" href="#comments-<?= $postId; ?>">
                                                <i class="bi bi-chat-left"></i>
                                                <span id="comment-count-<?= $postId; ?>"><?= $postComments; ?></span>
                                            </a>

                                        </div>
                                    </div>

                                    <!-- 💬 Comment Section -->
                                    <div class="collapse" id="comments-<?= $postId; ?>">
                                        <!-- Existing Comments -->
                                        <div class="comment-list">
                                            <?php foreach ($commentsForPost as $comment): ?>
                                                <?php
                                                $commentUser = trim($comment['first_name'] . ' ' . $comment['last_name']) ?: 'Anonymous';
                                                $commentTime = date('M d, Y H:i', strtotime($comment['created_at']));
                                                $commentContent = $comment['content'];
                                                $isCurrentUserComment = $comment['user_id'] == $userId;
                                                ?>
                                                <div class="d-flex gap-2 mb-3 comment-card" data-comment-id="<?= $comment['id']; ?>">
                                                    <div class="avatar comment-avatar bg-secondary"><?= strtoupper(substr($commentUser, 0, 1)); ?></div>
                                                    <div class="w-100">
                                                        <div class="d-flex justify-content-between">
                                                            <div>
                                                                <strong><?= sane($commentUser); ?></strong>
                                                                <small class="text-muted"> • <?= sane($commentTime); ?></small>
                                                            </div>
                                                            <?php if ($isCurrentUserComment): ?>
                                                                <div class="dropdown">
                                                                    <button class="btn btn-sm btn-link text-muted p-0" type="button" data-bs-toggle="dropdown">
                                                                        <i class="bi bi-three-dots"></i>
                                                                    </button>
                                                                    <ul class="dropdown-menu dropdown-menu-end">
                                                                        <li>
                                                                            <button class="dropdown-item btn-edit-comment"
                                                                                data-comment-id="<?= $comment['id']; ?>"
                                                                                data-comment-text="<?= htmlspecialchars($commentContent, ENT_QUOTES); ?>"
                                                                                data-post-index="<?= $postId; ?>">
                                                                                <i class="bi bi-pencil me-2"></i>Edit
                                                                            </button>

                                                                        </li>
                                                                        <li>
                                                                            <button class="dropdown-item text-danger btn-delete-comment"
                                                                                data-comment-id="<?= $comment['id']; ?>">
                                                                                <i class="bi bi-trash me-2"></i>Delete
                                                                            </button>
                                                                        </li>
                                                                    </ul>
                                                                </div>
                                                            <?php endif; ?>
                                                        </div>
                                                        <p class="mb-0 comment-text"><?= sane($commentContent); ?></p>
                                                    </div>
                                                </div>
                                            <?php endforeach; ?>
                                        </div>

                                        <!-- Comment Input -->
                                        <div class="d-flex gap-2 mt-3 pt-2 border-top">
                                            <div class="avatar comment-avatar bg-secondary"><?= $currentUser['initial'] ?? '?'; ?></div>
                                            <form method="POST" class="comment-form w-100 d-flex gap-2" data-post-id="<?= $postId; ?>" data-post-type="<?= $postType; ?>">
                                                <input type="text" name="comment_text" class="form-control form-control-sm rounded-pill" placeholder="Write a comment..." required>
                                                <button type="submit" class="btn btn-sm btn-success rounded-pill">
                                                    <i class="bi bi-send-fill"></i>
                                                </button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <div class="right-panel">
                <div class="card events-panel">
                    <div class="card-header"><i class="bi bi-calendar-event me-2"></i> Upcoming Events</div>
                    <ul class="list-group list-group-flush">
                        <?php if (!empty($events)): ?>
                            <?php foreach ($events as $event): ?>
                                <?php
                                $category = $event['category'] ?? 'general';
                                $title = $event['title'] ?? 'Untitled';
                                $date = $event['event_date'] ?? 'TBD';
                                $time = $event['time'] ?? '';
                                $location = $event['location'] ?? 'Location not set';
                                $attendees = $event['attendees'] ?? 0;
                                ?>
                                <li class="list-group-item event-card m-2">
                                    <div class="d-flex justify-content-between align-items-start">
                                        <div class="flex-grow-1">
                                            <span class="badge bg-info text-dark"><?= sane($title); ?></span>
                                            <h6 class="fw-bold mb-1"><?= sane($title); ?></h6>
                                            <p class="mb-0 small text-muted"><i class="bi bi-clock me-1"></i> <?= sane($date); ?><?= $time ? ' | ' . sane($time) : ''; ?></p>
                                            <p class="mb-0 small text-muted"><i class="bi bi-geo-alt me-1"></i> <?= sane($location); ?></p>
                                            <p class="mb-0 small mt-2"><i class="bi bi-people me-1"></i> <?= $attendees; ?> attending</p>
                                        </div>
                                        <form method="POST" class="attend-form" data-event-id="<?= $event['id'] ?>">
                                            <input type="hidden" name="event_id" value="<?= $event['id'] ?>">
                                            <input type="hidden" name="action" value="join">
                                            <button type="submit" class="btn btn-sm btn-outline-success join-btn">
                                                <i class="bi bi-person-plus"></i> Join Event
                                            </button>
                                        </form>
                                    </div>
                                </li>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <li class="list-group-item text-muted text-center">No upcoming events found.</li>
                        <?php endif; ?>
                        <li class="list-group-item text-center"><a href="#">View All Events</a></li>
                    </ul>
                </div>
                <?php if (!empty($pinnedPosts)): ?>
                    <div class="card pinned-panel mt-4">
                        <div class="card-header"><i class="bi bi-pin-angle me-2"></i> Pinned Posts</div>
                        <ul class="list-group list-group-flush">
                            <?php foreach ($pinnedPosts as $post): ?>
                                <?php
                                $postId = $post['id'];
                                $postUser = trim($post['first_name'] . ' ' . $post['last_name']) ?: 'Anonymous';
                                $postTitle = $post['title'] ?? 'Untitled';
                                $postTime = date('M d, Y H:i', strtotime($post['created_at']));
                                $postTag = $post['category'] ?? 'General';
                                $tagClass = $tagClassMap[$postTag] ?? 'tag-general';
                                ?>
                                <li class="list-group-item pinned-card m-2">
                                    <span class="badge <?= $tagClass; ?>"><?= htmlspecialchars($postTag, ENT_NOQUOTES); ?></span>
                                    <h6 class="fw-bold mb-1"><?= sane($postTitle); ?></h6>
                                    <p class="mb-0 small text-muted"><i class="bi bi-person me-1"></i> <?= sane($postUser); ?></p>
                                    <p class="mb-0 small text-muted"><i class="bi bi-clock me-1"></i> <?= sane($postTime); ?></p>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            console.log('Main script loaded');

            // 🔔 Tooltip Init
            const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]');
            [...tooltipTriggerList].forEach(el => new bootstrap.Tooltip(el));

            // ✅ Define getPostData()
            function getPostData(postEl) {
                return {
                    el: postEl,
                    title: postEl.querySelector('.post-title')?.textContent.toLowerCase() || '',
                    content: postEl.querySelector('.post-content-text')?.textContent.toLowerCase() || '',
                    tag: postEl.getAttribute('data-post-tag'),
                    likes: parseInt(postEl.getAttribute('data-post-likes') || '0'),
                    comments: parseInt(postEl.getAttribute('data-post-comments') || '0'),
                    timestamp: new Date(postEl.getAttribute('data-post-time'))
                };
            }

            // ✅ Global cache for all posts
            let allPosts = [];
            // On initial load, cache all posts
            const postsContainer = document.getElementById('postsContainer');
            const searchInput = document.getElementById('searchInput');
            const sortSelect = document.getElementById('sortSelect');
            const filterButtons = document.querySelectorAll('.filter-button-group .btn');

            allPosts = Array.from(postsContainer.querySelectorAll('.post-card')).map(getPostData); // ✅ Cache full list
            renderPosts(); // ✅ Initial render

            // 🔍 Extract post data for sorting/filtering
            function getPostData(postEl) {
                return {
                    el: postEl,
                    title: postEl.querySelector('.post-title')?.textContent.toLowerCase() || '',
                    content: postEl.querySelector('.post-content-text')?.textContent.toLowerCase() || '',
                    tag: postEl.getAttribute('data-post-tag'),
                    likes: parseInt(postEl.getAttribute('data-post-likes') || '0'),
                    comments: parseInt(postEl.getAttribute('data-post-comments') || '0'),
                    timestamp: new Date(postEl.getAttribute('data-post-time'))
                };
            }

            // 🔁 Rebind interactions after render
            function bindPostInteractions() {
                // ❤️ Like
                document.querySelectorAll('.btn-like').forEach(button => {
                    button.addEventListener('click', function() {
                        const postId = this.getAttribute('data-post-id');
                        console.log('Like clicked:', postId);
                        // Add your AJAX or toggle logic here
                    });
                });

                // 🔖 Bookmark
                document.querySelectorAll('.btn-bookmark').forEach(button => {
                    button.addEventListener('click', function() {
                        const postId = this.getAttribute('data-post-id');
                        console.log('Bookmark clicked:', postId);
                        // Add your bookmark logic here
                    });
                });

                // 💬 Comment (if applicable)
                document.querySelectorAll('.btn-comment').forEach(button => {
                    button.addEventListener('click', function() {
                        const postId = this.getAttribute('data-post-id');
                        console.log('Comment clicked:', postId);
                        // Add your comment logic here
                    });
                });

                // ✏️ Edit
                document.querySelectorAll('.edit-post-btn').forEach(button => {
                    button.addEventListener('click', function() {
                        const postId = this.getAttribute('data-index');
                        const title = this.getAttribute('data-title');
                        const content = this.getAttribute('data-content');
                        document.getElementById('editPostTitle').value = title;
                        document.getElementById('editPostContent').value = content;
                        document.getElementById('editPostId').value = postId;
                    });
                });
            }

            // 🔍 Search, 🔃 Sort, 🏷️ Filter Logic
            function renderPosts() {
                const query = searchInput.value.toLowerCase();
                const selectedTag = document.querySelector('.filter-button-group .btn.active')?.getAttribute('data-tag')?.toLowerCase() || '';
                const sortBy = sortSelect.value;

                const posts = allPosts // ✅ Always filter from full list
                    .filter(post =>
                        (!selectedTag || post.tag.toLowerCase() === selectedTag) &&
                        (post.title.includes(query) || post.content.includes(query))
                    );

                posts.sort((a, b) => {
                    if (sortBy === 'newest') return b.timestamp - a.timestamp;
                    if (sortBy === 'oldest') return a.timestamp - b.timestamp;
                    if (sortBy === 'mostLiked') return b.likes - a.likes;
                    if (sortBy === 'mostCommented') return b.comments - a.comments;
                    return 0;
                });

                postsContainer.innerHTML = '';
                posts.forEach(post => postsContainer.appendChild(post.el));
                bindPostInteractions(); // ✅ Rebind buttons after render
            }

            // 🔍 Search
            searchInput.addEventListener('input', renderPosts);

            // 🔃 Sort
            sortSelect.addEventListener('change', renderPosts);

            // 🏷️ Filter
            filterButtons.forEach(button => {
                button.addEventListener('click', function() {
                    filterButtons.forEach(btn => btn.classList.remove('active'));
                    this.classList.add('active');
                    renderPosts();
                });
            });

            // 🚀 Initial render
            renderPosts();
            loadNotifications();

            // 🔔 Notification Badge & Read Status + Fetching
            const bellButton = document.querySelector('[data-bs-toggle="dropdown"]');
            const badge = document.getElementById('notificationBadge');
            const unreadCount = document.getElementById('unreadCount');
            const notificationList = document.getElementById('notificationList');

            function loadNotifications() {
                fetch('fetch_notifications.php')
                    .then(res => res.json())
                    .then(data => {
                        console.log('🔔 Fetched notifications:', data); // ✅ Log the response array
                        const notificationList = document.getElementById('notificationList');
                        console.log('🔔 Injecting into:', notificationList); // ✅ Confirm the target container

                        if (Array.isArray(data) && data.length > 0) {
                            data.forEach(n => {
                                const item = document.createElement('li');
                                item.className = 'notification-item d-flex justify-content-between align-items-start p-3 border-bottom';
                                item.dataset.id = n.id; // ✅ This sets the notification ID

                                item.innerHTML = `
                                <a class="dropdown-item unread d-flex gap-2 p-0 flex-grow-1" href="#">
            <div class="avatar bg-${n.avatar_color} text-white fw-bold">${n.initials}</div>
            <div>
                <p class="mb-1"><strong>${n.sender_name}</strong> ${n.message}</p>
                <small class="text-muted">${n.created_at}</small>
            </div>
        </a>
        <button class="btn btn-sm btn-link text-danger delete-notifications" title="Remove">
            <i class="bi bi-x-circle"></i>
        </button>
    `;

                                notificationList.appendChild(item);
                            });

                            // Show badge and update count
                            badge.classList.remove('d-none');
                            unreadCount.textContent = data.length;
                        } else {
                            notificationList.innerHTML = '<li class="p-3 text-muted">No notifications</li>';
                            badge.classList.add('d-none');
                        }
                    });
            }


            // 🗑️ Delete Notification
            document.addEventListener('click', e => {
                const btn = e.target.closest('.delete-notifications');
                if (!btn) return;

                const item = btn.closest('.notification-item');
                if (!item) return;
                console.log('🗑️ Found item:', item);
                console.log('🗑️ Notification ID:', item?.dataset?.id);


                const notificationId = item.dataset.id;
                if (!notificationId) {
                    console.warn('🛑 Missing notification ID');
                    return;
                }

                fetch('delete_notifications.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded'
                        },
                        body: `id=${encodeURIComponent(notificationId)}`
                    })
                    .then(res => res.json())
                    .then(result => {
                        if (result.success) {
                            item.remove();
                            updateUnreadCount(-1);
                        } else {
                            alert('Failed to delete notification.');
                        }
                    });
                console.log('🗑️ Attempting to delete notification ID:', notificationId);

            });

            function updateUnreadCount(delta) {
                const count = document.getElementById('unreadCount');
                const badge = document.getElementById('notificationBadge');
                let current = parseInt(count.textContent || '0');
                let updated = Math.max(current + delta, 0);
                count.textContent = updated;
                badge.classList.toggle('d-none', updated === 0);
            }

            // 🧠 POST EDIT & DELETE HANDLER
            document.addEventListener('click', async e => {
                const editBtn = e.target.closest('.edit-post-btn');
                const deleteBtn = e.target.closest('.dropdown-item.text-danger');

                // ✏️ EDIT POST — open modal
                if (editBtn) {
                    const postId = editBtn.dataset.index;
                    const content = editBtn.dataset.content;
                    const title = editBtn.dataset.title || '';

                    document.getElementById('editPostTitle').value = title;
                    document.getElementById('editPostIndex').value = postId;
                    document.getElementById('editPostContent').value = content;

                    const modalEl = document.getElementById('editPostModal');
                    const modalInstance = bootstrap.Modal.getOrCreateInstance(modalEl);
                    modalInstance.show();

                }

                // 🗑️ DELETE POST — AJAX
                if (deleteBtn && deleteBtn.closest('form')) {
                    e.preventDefault();
                    const form = deleteBtn.closest('form');
                    const postId = form.querySelector('input[name="delete_post_id"]').value;

                    if (!confirm('Delete this post?')) return;

                    try {
                        const response = await fetch('delete_post.php', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/x-www-form-urlencoded',
                                'X-Requested-With': 'XMLHttpRequest'
                            },
                            credentials: 'include', // ✅ send session cookie!
                            body: `post_id=${postId}`
                        });

                        const result = await response.json();
                        if (result.success) {
                            const postCard = document.getElementById(`post-${postId}`);
                            if (postCard) postCard.remove();
                        } else {
                            alert(result.message || 'Failed to delete post');
                        }
                    } catch (err) {
                        console.error('Delete failed:', err);
                    }
                }
            });

            // 💾 HANDLE EDIT POST SUBMISSION
            document.getElementById('editPostForm').addEventListener('submit', async e => {
                e.preventDefault();

                const newTitle = document.getElementById('editPostTitle').value.trim();
                const postId = document.getElementById('editPostIndex').value;
                const newContent = document.getElementById('editPostContent').value.trim();

                if (!newContent) return;

                try {
                    const res = await fetch('edit_post.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded',
                            'X-Requested-With': 'XMLHttpRequest'
                        },
                        credentials: 'include',
                        body: `post_id=${encodeURIComponent(postId)}&post_title=${encodeURIComponent(newTitle)}&post_content=${encodeURIComponent(newContent)}`
                    });

                    const result = await res.json();
                    if (result.success) {
                        const postCard = document.getElementById(`post-${postId}`);
                        if (postCard) {
                            // ✅ Update content
                            const contentEl = postCard.querySelector('.post-content');
                            if (contentEl) contentEl.textContent = result.new_content;

                            // ✅ Update title
                            const titleEl = postCard.querySelector('.post-title');
                            if (titleEl) {
                                titleEl.textContent = result.new_title;
                            } else if (result.new_title) {
                                const metaBlock = postCard.querySelector('.d-flex.justify-content-between.align-items-start > div');
                                if (metaBlock) {
                                    const newTitleEl = document.createElement('h5');
                                    newTitleEl.className = 'post-title';
                                    newTitleEl.textContent = result.new_title;
                                    metaBlock.appendChild(newTitleEl);
                                }
                            }
                        }

                        // ✅ Update edit button's data attributes
                        const editBtn = document.querySelector(`.edit-post-btn[data-index="${postId}"]`);
                        if (editBtn) {
                            editBtn.dataset.content = newContent;
                            editBtn.dataset.title = newTitle;
                        }

                        // ✅ Close modal and reset form
                        const modalEl = document.getElementById('editPostModal');
                        const modalInstance = bootstrap.Modal.getOrCreateInstance(modalEl);
                        modalInstance.hide();
                        document.getElementById('editPostForm').reset();
                    } else {
                        alert(result.message || 'Failed to edit post.');
                    }
                } catch (err) {
                    console.error('Edit failed:', err);
                    alert('Something went wrong.');
                }
            });


            document.querySelectorAll('.comment-form').forEach(form => {
                form.addEventListener('submit', async e => {
                    e.preventDefault();

                    const postId = form.dataset.postId;
                    const postType = form.dataset.postType || 'community'; // fallback
                    const input = form.querySelector('input[name="comment_text"]');
                    const text = input.value.trim();

                    if (!text) return;

                    const button = form.querySelector('button[type="submit"]');
                    button.disabled = true;

                    const payload = new URLSearchParams({
                        comment_post_id: postId,
                        comment_post_type: postType,
                        comment_text: text
                    });

                    try {
                        const response = await fetch('comment.php', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/x-www-form-urlencoded',
                                'X-Requested-With': 'XMLHttpRequest'
                            },
                            body: payload
                        });

                        const raw = await response.text();
                        let result;

                        try {
                            result = JSON.parse(raw);
                        } catch (err) {
                            console.error('❌ Invalid JSON:', raw);
                            alert('Server error. Check console for details.');
                            return;
                        }

                        if (result.success && result.html) {
                            const commentList = document.querySelector(`#comments-${postId} .comment-list`);
                            commentList.insertAdjacentHTML('beforeend', result.html);
                            input.value = '';

                            // ✅ Update comment count
                            const countSpan = document.getElementById(`comment-count-${postId}`);
                            if (countSpan) {
                                countSpan.textContent = parseInt(countSpan.textContent || '0') + 1;
                            }

                            // 🔽 Auto-expand comment section
                            const collapse = form.closest('.collapse');
                            if (collapse && !collapse.classList.contains('show')) {
                                new bootstrap.Collapse(collapse, {
                                    toggle: true
                                });
                            }
                        } else {
                            alert(result.error || 'Comment failed.');
                        }
                    } catch (error) {
                        console.error('Comment submission failed:', error);
                        alert('Network error. Try again.');
                    } finally {
                        button.disabled = false;
                    }
                });
            });


            // ✏️ Comment Edit Modal
            const editCommentModal = document.getElementById('editCommentModal');
            const editCommentModalInstance = new bootstrap.Modal(editCommentModal);
            const editCommentIndex = document.getElementById('editCommentIndex');
            const editCommentText = document.getElementById('editCommentText');

            if (editCommentModal) {
                // document.addEventListener('click', e => {
                //     const editBtn = e.target.closest('.btn-edit-comment');
                //     if (editBtn) {
                //         const commentId = editBtn.dataset.commentId;
                //         const commentText = editBtn.dataset.commentText;

                //         editCommentIndex.value = commentId;
                //         editCommentText.value = commentText;

                //         editCommentModalInstance.show();
                //     }
                // });
                // // ✏️ Attach edit post buttons
                // document.querySelectorAll('.edit-post-btn').forEach(btn => {
                //     btn.setAttribute('data-bs-toggle', 'modal');
                //     btn.setAttribute('data-bs-target', '#editPostModal');
                // });

                // const editCommentModal = document.getElementById('editCommentModal');
                // const editCommentIndex = document.getElementById('editCommentIndex');
                // const editCommentText = document.getElementById('editCommentText');

                document.addEventListener('click', async e => {
                    // EDIT COMMENT
                    const editBtn = e.target.closest('.btn-edit-comment');
                    if (editBtn) {
                        const commentId = editBtn.dataset.commentId;
                        const commentText = editBtn.dataset.commentText;

                        editCommentIndex.value = commentId;
                        editCommentText.value = commentText;

                        editCommentModalInstance.show(); // use the single instance
                        return; // stop here to avoid triggering delete logic
                    }

                    // DELETE COMMENT
                    const deleteBtn = e.target.closest('.btn-delete-comment');
                    if (deleteBtn) {
                        const commentId = deleteBtn.dataset.commentId;
                        const commentCard = document.querySelector(`[data-comment-id="${commentId}"]`);
                        const postContainer = commentCard.closest('.collapse');
                        const postId = postContainer?.id.replace('comments-', '');

                        if (confirm('Delete this comment?')) {
                            try {
                                const response = await fetch('delete_comment.php', {
                                    method: 'POST',
                                    headers: {
                                        'Content-Type': 'application/x-www-form-urlencoded',
                                        'X-Requested-With': 'XMLHttpRequest'
                                    },
                                    body: `comment_id=${commentId}`
                                });

                                const result = await response.json();
                                if (result.success) {
                                    commentCard.remove();
                                    if (postId) {
                                        const counter = document.getElementById(`comment-count-${postId}`);
                                        if (counter) {
                                            let current = parseInt(counter.textContent.trim(), 10) || 0;
                                            if (current > 0) counter.textContent = current - 1;
                                        }
                                    }
                                }
                            } catch (error) {
                                console.error('Comment deletion failed:', error);
                            }
                        }
                    }
                });


                // ✅ Handle comment edit submission
                document.getElementById('editCommentForm').addEventListener('submit', async e => {
                    e.preventDefault();

                    const commentId = document.getElementById('editCommentIndex').value;
                    const text = document.getElementById('editCommentText').value.trim();

                    try {
                        const response = await fetch('edit_comment.php', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/x-www-form-urlencoded',
                                'X-Requested-With': 'XMLHttpRequest'
                            },
                            body: `comment_id=${commentId}&comment_text=${encodeURIComponent(text)}`
                        });

                        const result = await response.json();
                        if (result.success) {
                            const commentCard = document.querySelector(`[data-comment-id="${commentId}"]`);
                            if (commentCard) {
                                commentCard.querySelector('.comment-text').textContent = text;

                                // ✅ Update the edit button's data-comment-text
                                const editButton = commentCard.querySelector('.btn-edit-comment');
                                if (editButton) {
                                    editButton.setAttribute('data-comment-text', text);
                                }

                                // ✅ Hide the modal
                                bootstrap.Modal.getInstance(editCommentModal).hide();
                            }
                        } else {
                            alert(result.message || 'Edit failed.');
                        }
                    } catch (error) {
                        console.error('Comment edit failed:', error);
                        alert('Network error.');
                    }
                    editCommentModalInstance.hide();

                });
            }


            // ❤️ AJAX Like Handler
            document.querySelectorAll('.btn-like').forEach(button => {
                button.addEventListener('click', async () => {
                    const postId = button.dataset.postId;
                    try {
                        const response = await fetch('like.php', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/x-www-form-urlencoded',
                                'X-Requested-With': 'XMLHttpRequest'
                            },
                            body: `like_post_id=${postId}`
                        });

                        const result = await response.json();
                        if (!result.success) return;

                        const icon = button.querySelector('i');
                        const count = button.querySelector('.like-count');

                        if (icon) {
                            icon.className = result.liked ? 'bi bi-heart-fill text-danger' : 'bi bi-heart';
                        }

                        button.classList.toggle('liked', result.liked);
                        if (count) count.textContent = result.total_likes;
                    } catch (error) {
                        console.error('Like toggle failed:', error);
                    }
                });
            });

            // 📌 Bookmark toggle
            document.querySelectorAll('.btn-bookmark').forEach(button => {
                button.addEventListener('click', async () => {
                    const postId = button.dataset.postId;
                    try {
                        const response = await fetch('bookmark.php', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/x-www-form-urlencoded',
                                'X-Requested-With': 'XMLHttpRequest'
                            },
                            body: `bookmark_post_id=${postId}`
                        });

                        const result = await response.json();
                        if (result.success) {
                            const icon = button.querySelector('i');
                            icon.className = result.bookmarked ? 'bi bi-bookmark-fill text-warning' : 'bi bi-bookmark';
                        }
                    } catch (error) {
                        console.error('Bookmark toggle failed:', error);
                    }
                });
            });

            document.querySelectorAll('.attend-form').forEach(form => {
                const button = form.querySelector('.join-btn');
                const eventId = form.dataset.eventId;
                const actionInput = form.querySelector('input[name="action"]');

                // Initial state check
                fetch(`get_attendees.php?event_id=${eventId}`)
                    .then(res => res.json())
                    .then(data => {
                        const attendees = data.attendees || [];
                        const isAttending = data.attending ?? attendees.some(a => a.is_current_user);

                        updateButtonState(button, isAttending);
                        actionInput.value = isAttending ? 'leave' : 'join';
                    });

                // Handle submit without refresh
                form.addEventListener('submit', function(e) {
                    e.preventDefault();
                    const action = actionInput.value;

                    fetch('event_attend_action.php', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/x-www-form-urlencoded',
                                'X-Requested-With': 'XMLHttpRequest' // 👈 this tells PHP it's AJAX
                            },
                            body: `event_id=${eventId}&action=${action}`
                        })

                        .then(res => res.json())
                        .then(result => {
                            if (result.success) {
                                // Re-fetch attendee data to update button and count
                                fetch(`get_attendees.php?event_id=${eventId}`)
                                    .then(res => res.json())
                                    .then(data => {
                                        const attendees = data.attendees || [];
                                        const isAttending = data.attending ?? attendees.some(a => a.is_current_user);

                                        updateButtonState(button, isAttending);
                                        actionInput.value = isAttending ? 'leave' : 'join';

                                        // Update attendee count
                                        const countText = form.closest('.event-card').querySelector('.bi-people').parentElement;
                                        countText.innerHTML = `<i class="bi bi-people me-1"></i> ${attendees.length} attending`;
                                    });
                            } else {
                                alert(result.error || 'Failed to update attendance.');
                            }
                        })
                        .catch(err => {
                            console.error(`❌ Failed to submit attendance for event ${eventId}:`, err);
                        });
                });
            });

            let reportModalInstance = null;

            // 🏳️ Report Post Modal Setup
            const reportModal = document.getElementById('reportModal');
            reportModal.addEventListener('show.bs.modal', function(event) {
                const trigger = event.relatedTarget;
                const postId = trigger.getAttribute('data-post-id');
                const categoryId = trigger.getAttribute('data-category-id');

                document.getElementById('reportPostId').value = postId;
                document.getElementById('reportCategoryId').value = categoryId;
            });


            // Show/hide "Other" reason textarea
            const reasonSelect = document.getElementById('reason');
            const otherDiv = document.getElementById('otherReasonDiv');
            reasonSelect.addEventListener('change', () => {
                const isOther = reasonSelect.value === 'Other';
                otherDiv.style.display = isOther ? 'block' : 'none';
                document.getElementById('other_reason').required = isOther;
            });

            // Open modal and set post ID & type
            document.querySelectorAll('.report-post-btn').forEach(btn => {
                btn.addEventListener('click', e => {
                    // e.preventDefault();
                    const postId = btn.getAttribute('data-post-id');
                    const postType = btn.getAttribute('data-post-type') || 'general';
                    document.getElementById('reportPostId').value = postId;
                    document.getElementById('reportPostType').value = postType;

                    const modalElement = document.getElementById('reportModal');
                    // reportModalInstance = new bootstrap.Modal(modalElement);
                    // reportModalInstance.show();
                });
            });

            // Submit report via AJAX
            document.getElementById('reportForm').addEventListener('submit', async function(e) {
                e.preventDefault();

                const formData = new FormData(this);
                const reason = formData.get('reason');
                const otherDiv = document.getElementById('otherReasonDiv');

                if (reason === 'Other') {
                    const otherText = document.getElementById('other_reason').value.trim();
                    if (!otherText) {
                        alert('Please specify your reason.');
                        return;
                    }
                    formData.set('reason', otherText);
                }

                try {
                    const res = await fetch('report_post.php', {
                        method: 'POST',
                        body: formData
                    });

                    const data = await res.json();
                    alert(data.message);
                    if (data.success) {
                        const modalElement = document.getElementById('reportModal');
                        const instance = bootstrap.Modal.getInstance(modalElement);
                        if (instance) instance.hide();
                        this.reset();
                        otherDiv.style.display = 'none';
                    }
                } catch (err) {
                    console.error(err);
                    alert('Error reporting post.');
                }
            });

            // Update Attend/Leave button state
            function updateButtonState(button, isAttending) {
                if (!button) return;

                if (isAttending) {
                    button.classList.remove('btn-outline-success');
                    button.classList.add('btn-outline-danger');
                    button.innerHTML = '<i class="bi bi-person-dash"></i> Leave Event';
                } else {
                    button.classList.remove('btn-outline-danger');
                    button.classList.add('btn-outline-success');
                    button.innerHTML = '<i class="bi bi-person-plus"></i> Join Event';
                }
            }


            // 🔐 Logout Confirmation
            window.confirmLogout = function() {
                if (confirm("Are you sure you want to log out?")) {
                    document.getElementById('logoutForm').submit();
                }
            };

            // ⚠️ Placeholder Alert
            window.showCustomAlert = function(message) {
                alert(message);
            };

        });
    </script>
</body>

</html>